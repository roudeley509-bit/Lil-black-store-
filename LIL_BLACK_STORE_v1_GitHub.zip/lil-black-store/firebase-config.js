// Mete enfòmasyon Firebase pwojè LIL BLACK STORE la isit la.
// Firebase web config pa sekrè; PA mete Admin SDK private key oswa lòt sekrè nan fichye sa a.
export const firebaseConfig = {
  apiKey: "METE_API_KEY_ISIT",
  authDomain: "METE_PROJECT_ID.firebaseapp.com",
  projectId: "METE_PROJECT_ID",
  storageBucket: "METE_PROJECT_ID.appspot.com",
  messagingSenderId: "METE_SENDER_ID",
  appId: "METE_APP_ID"
};

// Paramèt magazen. Ranpli nimewo MonCash la ak frè livrezon yo anvan piblikasyon.
export const storeConfig = {
  storeName: "LIL BLACK STORE",
  moncashNumber: "METE_NIMEWO_MONCASH_LA",
  moncashName: "LIL BLACK STORE",
  exchangeRateHTGPerUSD: 132,
  localDeliveryHTG: 150,
  nationalDeliveryHTG: 350,
  defaultCurrency: "HTG",
  whatsappNumber: ""
};
