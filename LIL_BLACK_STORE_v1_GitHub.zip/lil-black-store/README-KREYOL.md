# LIL BLACK STORE — Premye vèsyon

Sit e-commerce pou rad, soulye ak akseswa fizik. Frontend la se HTML/CSS/JavaScript, Firebase se backend, epi GitHub Pages se hosting.

## Sa premye vèsyon an genyen
- Paj dakèy premium, adapte pou telefòn.
- Kategori, rechèch, filtè ak lis pwodwi.
- Panyen acha ki rete nan navigatè a.
- Kont kliyan ak Firebase Authentication (imèl/modpas).
- Kòmand ki anrejistre nan Firestore ak paj istorik kòmand kliyan.
- HTG ak USD; to chanj `132` nan `firebase-config.js` se yon valè DEMO pou ranplase ak to ou verifye a.
- Livrezon lokal/nasyonal; frè yo ka modifye nan `firebase-config.js`.
- Dashboard administratè ak custom claim `admin: true`.
- Jesyon pwodwi ak estati kòmand.

## 1. Mete Firebase
1. Kreye oswa chwazi pwojè Firebase pou LIL BLACK STORE.
2. Nan Firebase Console, aktive Authentication > Email/Password.
3. Kreye Firestore Database.
4. Aktive Storage.
5. Nan Project settings > Your apps, kreye yon Web App.
6. Kopi `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId` nan `firebase-config.js`.
7. Ranplase tout valè `METE_...`.
8. Mete nimewo MonCash magazen an, to HTG/USD ak frè livrezon yo nan menm fichye a.
9. Pibliye `firestore.rules` ak `storage.rules` nan Firebase Console.

**Pa mete okenn Admin SDK private key nan frontend/GitHub.** Firebase web config la pa yon modpas; sekirite a soti nan Rules ak wòl administratè.

## 2. Bay kont administratè a dwa admin
Pa janm fè yon kliyan vin admin atravè yon bouton sou sit la. Custom claim lan dwe bay sou bò sèvè, avèk Firebase Admin SDK nan yon anviwònman prive. Egzanp Node.js (kouri lokalman sou òdinatè ou, avèk Admin SDK kredansyèl ki pa nan repo a):

```js
await getAuth().setCustomUserClaims("FIREBASE_UID_ADMIN_AN", { admin: true });
```

Apre sa, dekonekte epi rekonekte kont administratè a. Ranplase UID la ak UID kont ou nan Firebase Authentication.

## 3. Pibliye sou GitHub Pages
1. Kreye yon repository GitHub, pa egzanp `lil-black-store`.
2. Upload tout fichye ki nan dosye sa a nan rasin repository a.
3. Ale Settings > Pages.
4. Nan Build and deployment, chwazi Deploy from a branch.
5. Chwazi branch `main` ak folder `/ (root)`, epi Save.
6. Tann GitHub bay URL sit la.

## 4. Peman MonCash
Premye vèsyon sa a pran referans tranzaksyon an epi mete kòmand lan sou `pending_verification`. Administratè a verifye peman an anvan li konfime kòmand lan.

Pou peman otomatik MonCash, bezwen:
- Merchant account ak API credentials MonCash;
- backend sekirize (pa GitHub Pages);
- endpoint sèvè pou kreye/verifye tranzaksyon ak webhook/callback;
- pa janm mete secret key MonCash nan `app.js` oswa `firebase-config.js`.

## 5. Enpòtan anvan lavant reyèl
- Verifye pri, stock ak frè livrezon sou sèvè a anvan peman. Kliyan ka modifye JavaScript nan navigatè li; total ki soti nan browser pa dwe konsidere kòm otorite.
- Pou premye MVP a, administratè a dwe verifye kòmand ak peman manyèlman.
- Ajoute Cloud Function oswa backend pou kalkile total la ak valide stock anvan w ouvri peman otomatik.
- Chanje echantiyon pwodwi yo ak foto, pri, deskripsyon ak stock reyèl.
- Mete nimewo MonCash, to echanj ak frè livrezon egzak.
- Pa kolekte oswa estoke PIN MonCash kliyan.

## Estrikti
```
lil-black-store/
├── index.html
├── styles.css
├── app.js
├── firebase-config.js
├── firestore.rules
├── storage.rules
└── README-KREYOL.md
```
