import { firebaseConfig, storeConfig } from "./firebase-config.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, doc, getDoc, getDocs, addDoc, setDoc, updateDoc, deleteDoc, query, where, orderBy, limit, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const $ = (s) => document.querySelector(s);
const money = (n,c) => new Intl.NumberFormat("en-US",{maximumFractionDigits:c==="USD"?2:0}).format(Number(n)||0)+" "+c;
const validFirebase = firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("METE_") && firebaseConfig.projectId && !firebaseConfig.projectId.startsWith("METE_");
let app=null, auth=null, db=null, currentUser=null, isAdmin=false, products=[], cart=JSON.parse(localStorage.getItem("lbs_cart")||"[]"), currency=localStorage.getItem("lbs_currency")||storeConfig.defaultCurrency;
const demoProducts=[
 {id:"demo-tee",name:"Essential Oversized Tee",category:"T-Shirts",priceHTG:1800,priceUSD:14,image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80",description:"T-shirt oversized, style senp ak premium.",sizes:["S","M","L","XL"],stock:12,featured:true},
 {id:"demo-hoodie",name:"Classic Street Hoodie",category:"Hoodies",priceHTG:4200,priceUSD:32,image:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=800&q=80",description:"Hoodie konfòtab pou chak jou.",sizes:["M","L","XL"],stock:8,featured:true},
 {id:"demo-pants",name:"Urban Denim Pants",category:"Pants",priceHTG:3500,priceUSD:27,image:"https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=800&q=80",description:"Pantalon denim ak koupe modèn.",sizes:["30","32","34","36"],stock:7},
 {id:"demo-shoes",name:"Street Runner Sneakers",category:"Shoes",priceHTG:6500,priceUSD:49, image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80",description:"Soulye streetwear pou yon stil aktif.",sizes:["40","41","42","43"],stock:5},
 {id:"demo-watch",name:"Minimal Timepiece",category:"Accessories",priceHTG:5200,priceUSD:39,image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80",description:"Mont minimalist pou konplete stil ou.",sizes:["One size"],stock:4}
];
if(validFirebase){try{app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);onAuthStateChanged(auth,async u=>{currentUser=u;isAdmin=false;if(u){try{const token=await u.getIdTokenResult(true);isAdmin=token.claims.admin===true;}catch(e){} }renderAccountState();if(isAdmin)$("#adminEntry")?.classList.remove("hidden");});}catch(e){console.error(e);toast("Firebase pa inisyalize. Verifye firebase-config.js.");}}
else {currentUser=null;}

function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(window.__lbsToast);window.__lbsToast=setTimeout(()=>el.classList.remove("show"),2800);}
function priceOf(p,c=currency){return c==="USD"?(p.priceUSD??Number(p.priceHTG||0)/storeConfig.exchangeRateHTGPerUSD):(p.priceHTG??Number(p.priceUSD||0)*storeConfig.exchangeRateHTGPerUSD);}
function displayPrice(p){return money(priceOf(p),currency);}
function saveCart(){localStorage.setItem("lbs_cart",JSON.stringify(cart));renderCart();}
function getProduct(id){return products.find(p=>p.id===id)||demoProducts.find(p=>p.id===id);}
function renderProducts(){
 const term=($("#searchInput").value||"").toLowerCase(),cat=$("#categoryFilter").value;
 const list=products.filter(p=>(cat==="all"||p.category===cat)&&(`${p.name} ${p.category} ${p.description||""}`).toLowerCase().includes(term));
 $("#productGrid").innerHTML=list.length?list.map(p=>`<article class="product-card"><div style="position:relative"><img class="product-image" src="${escapeHtml(p.image||"")}" alt="${escapeHtml(p.name)}" loading="lazy"><span class="product-tag">${p.featured?"FEATURED":"LIL BLACK"}</span></div><div class="product-info"><span class="product-category">${escapeHtml(p.category||"FASHION")}</span><h3 class="product-name">${escapeHtml(p.name)}</h3><div class="product-bottom"><span class="product-price">${displayPrice(p)}</span><button class="add-btn" data-add="${p.id}">ADD TO BAG +</button></div></div></article>`).join(""):`<div class="empty">Pa gen pwodwi ki koresponn ak rechèch sa a.</div>`;
}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function loadProducts(){
 if(db){try{const snap=await getDocs(query(collection(db,"products"),where("active","==",true)));products=snap.docs.map(d=>({id:d.id,...d.data()}));}catch(e){console.error(e);products=[];}}
 if(!products.length)products=demoProducts;
 renderProducts();
}
function addToCart(id){const p=getProduct(id);if(!p)return;const row=cart.find(x=>x.id===id);if(row)row.qty++;else cart.push({id,qty:1});saveCart();toast("Pwodwi ajoute nan panyen an.");}
function renderCart(){
 $("#cartCount").textContent=cart.reduce((n,x)=>n+x.qty,0);
 const rows=cart.map(x=>({...x,p:getProduct(x.id)})).filter(x=>x.p);
 $("#cartItems").innerHTML=rows.length?rows.map(({id,qty,p})=>`<div class="cart-row"><img src="${escapeHtml(p.image||"")}" alt=""><div><b>${escapeHtml(p.name)}</b><small>${displayPrice(p)}</small><div class="qty-controls"><button data-qty="${id}" data-delta="-1">−</button><span>${qty}</span><button data-qty="${id}" data-delta="1">+</button></div></div><button class="close-btn" data-remove="${id}" aria-label="Retire">×</button></div>`).join(""):`<p class="muted">Panyen an vid. Chwazi kèk pwodwi pou kòmanse.</p>`;
 const subtotal=rows.reduce((n,x)=>n+priceOf(x.p)*x.qty,0);$("#cartSubtotal").textContent=money(subtotal,currency);
}
function openModal(id){$("#"+id).classList.add("open");$("#"+id).setAttribute("aria-hidden","false");}
function closeModal(id){$("#"+id).classList.remove("open");$("#"+id).setAttribute("aria-hidden","true");}
function openCart(){$("#cartDrawer").classList.add("open");$("#drawerBackdrop").classList.add("show");}
function closeCart(){$("#cartDrawer").classList.remove("open");$("#drawerBackdrop").classList.remove("show");}
function renderAccountState(){
 const logged=!!currentUser;
 $("#authTitle").textContent=logged?"MY ACCOUNT":"MY ACCOUNT";
 $("#loginForm").classList.toggle("hidden",logged||!$("#showLogin").classList.contains("hidden"));
 $("#registerForm").classList.add("hidden");
 $("#showRegister").classList.toggle("hidden",logged);
 $("#showLogin").classList.toggle("hidden",logged);
 $("#logoutBtn").classList.toggle("hidden",!logged);
 if(logged)$("#authStatus").textContent=`Konekte kòm ${currentUser.email||currentUser.displayName||"kliyan"}. ${isAdmin?"Ou gen dwa administratè.":""}`;
 else $("#authStatus").textContent=validFirebase?"Konekte oswa kreye kont ou pou swiv kòmand yo.":"Mòd demonstrasyon: ranpli Firebase config la pou aktive kont kliyan.";
 $("#authStatus").classList.remove("hidden");
 $("#customerOrders").classList.toggle("hidden",!logged);
 if(logged && db) loadMyOrders();
}
async function loadMyOrders(){
 const box=$("#customerOrders");
 if(!currentUser||!db)return;
 box.innerHTML="<h3>MY ORDERS</h3><p class='muted'>Ap chaje kòmand yo...</p>";
 try{
   const snap=await getDocs(query(collection(db,"orders"),where("uid","==",currentUser.uid)));
   const orders=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));
   const labels={pending:"An atant",confirmed:"Konfime",processing:"Ap prepare",shipped:"Voye",delivered:"Livre",cancelled:"Anile"};
   box.innerHTML="<h3>MY ORDERS</h3>"+(orders.length?orders.map(o=>`<div class="admin-list"><b>${escapeHtml(o.id.slice(0,10))}</b> · ${money(o.totalHTG||0,"HTG")}<br><small>Estati: ${labels[o.status]||escapeHtml(o.status||"An atant")}</small></div>`).join(""):"<p class='muted'>Ou poko gen kòmand.</p>");
 }catch(e){box.innerHTML="<h3>MY ORDERS</h3><p class='muted'>Nou pa ka chaje kòmand yo kounye a.</p>";}
}
async function loadAdmin(){
 if(!isAdmin||!db){$("#adminContent").innerHTML="<p class='notice'>Aksè administratè pa disponib. Konekte ak yon kont ki gen Firebase custom claim <b>admin: true</b>.</p>";return;}
 const [ps,os]=await Promise.all([getDocs(collection(db,"products")),getDocs(query(collection(db,"orders"),orderBy("createdAt","desc"),limit(40)))]);
 const orders=os.docs.map(d=>({id:d.id,...d.data()}));const total=orders.filter(o=>o.status==="delivered").reduce((s,o)=>s+Number(o.totalHTG||0),0);
 $("#adminContent").innerHTML=`<div class="admin-stat"><b>${ps.size}</b>Products</div><div class="admin-stat"><b>${orders.length}</b>Orders</div><div class="admin-stat"><b>${money(total,"HTG")}</b>Delivered sales</div>
 <h3>Ajoute yon pwodwi</h3><form id="addProductForm" class="admin-form"><label>Non<input name="name" required></label><label>Kategori<select name="category"><option>T-Shirts</option><option>Hoodies</option><option>Pants</option><option>Shoes</option><option>Accessories</option></select></label><label>Pri HTG<input name="priceHTG" type="number" min="1" required></label><label>Pri USD<input name="priceUSD" type="number" min="0" step=".01"></label><label>Stock<input name="stock" type="number" min="0" value="1"></label><label>URL foto<input name="image" type="url" required></label><label>Deskripsyon<input name="description"></label><button class="button button-orange">SAVE PRODUCT</button></form>
 <h3>Pwodwi yo</h3>${ps.docs.map(d=>{const p=d.data();return `<div class="admin-list"><b>${escapeHtml(p.name)}</b> · ${money(p.priceHTG,"HTG")} · Stock ${p.stock??0}<button class="add-btn" data-delete-product="${d.id}">DELETE</button></div>`}).join("")}
 <h3>Dènye kòmand</h3>${orders.map(o=>`<div class="admin-list"><b>${escapeHtml(o.customer?.name||"Kliyan")}</b> · ${money(o.totalHTG||0,"HTG")} · ${escapeHtml(o.status||"pending")}<br><small>${escapeHtml(o.customer?.phone||"")} / ${escapeHtml(o.id)}</small><div class="admin-toolbar"><button class="add-btn" data-order-status="${o.id}" data-status="confirmed">CONFIRM</button><button class="add-btn" data-order-status="${o.id}" data-status="processing">PROCESS</button><button class="add-btn" data-order-status="${o.id}" data-status="shipped">SHIP</button><button class="add-btn" data-order-status="${o.id}" data-status="delivered">DELIVER</button></div></div>`).join("")||"<p>Pa gen kòmand toujou.</p>"}`;
 $("#addProductForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);await addDoc(collection(db,"products"),{name:f.get("name"),category:f.get("category"),priceHTG:Number(f.get("priceHTG")),priceUSD:Number(f.get("priceUSD")||0),stock:Number(f.get("stock")||0),image:f.get("image"),description:f.get("description"),active:true,createdAt:serverTimestamp()});toast("Pwodwi ajoute.");await loadProducts();await loadAdmin();});
}
async function submitOrder(form){
 if(!cart.length){toast("Panyen an vid.");return;}
 if(!db||!currentUser){$("#checkoutNotice").textContent="Pou voye yon kòmand reyèl, aktive Firebase epi konekte ak yon kont kliyan. Mòd demonstrasyon pa voye kòmand.";$("#checkoutNotice").classList.remove("hidden");return;}
 const f=new FormData(form),delivery=f.get("deliveryType"),curr=f.get("currency"),rate=Number(storeConfig.exchangeRateHTGPerUSD)||132;
 const items=cart.map(x=>{const p=getProduct(x.id);return {productId:x.id,name:p.name,qty:x.qty,unitPriceHTG:Number(p.priceHTG??priceOf(p,"HTG")),unitPriceUSD:Number(p.priceUSD??priceOf(p,"USD"))};});
 const subtotalHTG=items.reduce((s,x)=>s+x.unitPriceHTG*x.qty,0);
 const deliveryHTG=delivery==="local"?Number(storeConfig.localDeliveryHTG):Number(storeConfig.nationalDeliveryHTG);
 const totalHTG=subtotalHTG+deliveryHTG;
 const order={uid:currentUser.uid,customer:{name:f.get("name"),phone:f.get("phone"),email:f.get("email"),department:f.get("department"),city:f.get("city"),address:f.get("address")},items,currency:curr,subtotalHTG,deliveryHTG,totalHTG,totalUSD:Number((totalHTG/rate).toFixed(2)),deliveryType:delivery,paymentMethod:"moncash",paymentReference:f.get("paymentReference")||"",paymentStatus:"pending_verification",status:"pending",createdAt:serverTimestamp()};
 try{const ref=await addDoc(collection(db,"orders"),order);cart=[];saveCart();closeModal("checkoutModal");closeCart();toast("Kòmand voye! Nimewo kòmand: "+ref.id);form.reset();}catch(e){console.error(e);toast("Kòmand lan pa pase. Verifye koneksyon ak Firebase Rules.");}
}

$("#productGrid").addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(b)addToCart(b.dataset.add);});
$("#cartItems").addEventListener("click",e=>{const q=e.target.closest("[data-qty]"),r=e.target.closest("[data-remove]");if(q){const x=cart.find(i=>i.id===q.dataset.qty);if(x){x.qty+=Number(q.dataset.delta);if(x.qty<1)cart=cart.filter(i=>i.id!==x.id);saveCart();}}if(r){cart=cart.filter(i=>i.id!==r.dataset.remove);saveCart();}});
$("#cartBtn").onclick=openCart;$("#drawerBackdrop").onclick=closeCart;$("#checkoutBtn").onclick=()=>{if(!cart.length){toast("Panyen an vid.");return;}closeCart();$("#checkoutCurrency").value=currency;updateCheckoutTotal();$("#moncashInstructions").textContent=`Voye peman sou MonCash: ${storeConfig.moncashNumber}. Non kont: ${storeConfig.moncashName}. Administratè a ap verifye peman an anvan li konfime kòmand lan.`;openModal("checkoutModal");};
$("#checkoutForm").addEventListener("submit",e=>{e.preventDefault();submitOrder(e.currentTarget);});
$("#accountBtn").onclick=()=>{renderAccountState();openModal("accountModal");};$("#footerAccount").onclick=()=>{renderAccountState();openModal("accountModal");};
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>closeModal(b.dataset.close));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)closeModal(m.id);}));
$("#showRegister").onclick=()=>{$("#registerForm").classList.remove("hidden");$("#loginForm").classList.add("hidden");$("#showRegister").classList.add("hidden");$("#showLogin").classList.remove("hidden");};
$("#showLogin").onclick=()=>{$("#registerForm").classList.add("hidden");$("#loginForm").classList.remove("hidden");$("#showLogin").classList.add("hidden");$("#showRegister").classList.remove("hidden");};
$("#registerForm").addEventListener("submit",async e=>{e.preventDefault();if(!auth){toast("Mete Firebase config la anvan.");return;}const f=new FormData(e.currentTarget);try{const cred=await createUserWithEmailAndPassword(auth,f.get("email"),f.get("password"));await updateProfile(cred.user,{displayName:f.get("name")});await setDoc(doc(db,"users",cred.user.uid),{name:f.get("name"),phone:f.get("phone"),email:f.get("email"),createdAt:serverTimestamp()});toast("Kont ou kreye.");closeModal("accountModal");}catch(err){toast(err.message);}});
$("#loginForm").addEventListener("submit",async e=>{e.preventDefault();if(!auth){toast("Mete Firebase config la anvan.");return;}const f=new FormData(e.currentTarget);try{await signInWithEmailAndPassword(auth,f.get("email"),f.get("password"));toast("Ou konekte.");closeModal("accountModal");}catch(err){toast("Koneksyon echwe: verifye imel ak modpas.");}});
$("#logoutBtn").onclick=async()=>{if(auth)await signOut(auth);closeModal("accountModal");toast("Ou dekonekte.");};
$("#currencySelect").value=currency;$("#checkoutCurrency").value=currency;
$("#currencySelect").onchange=e=>{currency=e.target.value;localStorage.setItem("lbs_currency",currency);renderProducts();renderCart();updateCheckoutTotal();};
$("#checkoutCurrency").onchange=updateCheckoutTotal;
function updateCheckoutTotal(){const curr=$("#checkoutCurrency").value,delivery=$("#checkoutForm").elements.deliveryType.value,rate=Number(storeConfig.exchangeRateHTGPerUSD)||132;const subtotal=cart.reduce((s,x)=>{const p=getProduct(x.id);return s+(p?priceOf(p,curr)*x.qty:0)},0);const feeHTG=delivery==="local"?Number(storeConfig.localDeliveryHTG):Number(storeConfig.nationalDeliveryHTG);$("#checkoutTotal").textContent=money(subtotal+(curr==="USD"?feeHTG/rate:feeHTG),curr);}
$("#checkoutForm").elements.deliveryType.addEventListener("change",updateCheckoutTotal);
$("#searchInput").oninput=renderProducts;$("#categoryFilter").onchange=renderProducts;
document.querySelectorAll("[data-category]").forEach(b=>b.onclick=()=>{$("#categoryFilter").value=b.dataset.category;renderProducts();location.hash="#shop";});
$("#mobileMenuBtn").onclick=()=>$("#mobileNav").classList.toggle("open");
$("#year").textContent=new Date().getFullYear();
$("#adminEntry")?.addEventListener("click",async()=>{openModal("adminModal");await loadAdmin();});
$("#adminContent").addEventListener("click",async e=>{const d=e.target.closest("[data-delete-product]"),s=e.target.closest("[data-order-status]");if(d&&isAdmin){if(confirm("Efase pwodwi sa a?")){await deleteDoc(doc(db,"products",d.dataset.deleteProduct));toast("Pwodwi efase.");await loadProducts();await loadAdmin();}}if(s&&isAdmin){await updateDoc(doc(db,"orders",s.dataset.orderStatus),{status:s.dataset.status,updatedAt:serverTimestamp()});toast("Estati kòmand modifye.");await loadAdmin();}});
const adminLink=document.createElement("button");adminLink.id="adminEntry";adminLink.className="hidden";adminLink.textContent="ADMIN";adminLink.style.cssText="position:fixed;right:12px;bottom:12px;z-index:30;background:#f47721;border:0;padding:10px;font-weight:900";adminLink.addEventListener("click",async()=>{openModal("adminModal");await loadAdmin();});document.body.appendChild(adminLink);
$("#checkoutForm").elements.deliveryType.addEventListener("change",updateCheckoutTotal);
renderCart();loadProducts();
